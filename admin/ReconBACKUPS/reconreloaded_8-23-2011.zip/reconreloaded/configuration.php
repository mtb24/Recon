<?php

global $configuration;

// database settings
$configuration['db']	= 'recon';	        //	<- database name
$configuration['host'] 	= 'localhost';	        //	<- database host
$configuration['user'] 	= 'root';		//	<- database user
$configuration['pass']	= 'br54!6A';	        //	<- database password
$configuration['port']	= '8889';		//	<- database port

?>
